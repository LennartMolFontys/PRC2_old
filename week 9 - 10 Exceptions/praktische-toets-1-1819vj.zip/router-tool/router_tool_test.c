#include "router_tool.h"
#include "unity.h"

#define MY_RUN_TEST(func) RUN_TEST(func, 0)

/*-----------------------------------------------------------------*/
void setUp(void)
{
  //printf("This is run before EACH test.\n");
}

void tearDown(void)
{
    //printf("This is run after EACH test.\n");
}
/*-----------------------------------------------------------------*/
void test_router_tool_setters(void) {
  uint8_t bitsThatNeedToBeIgnored =  0b10101000;
  uint8_t connectionType = 0b10;
  uint8_t operationMode = 0b01;
  uint8_t wifiPowerAdjustment = 0b101;
  uint8_t packed = 0xFF;

  TEST_ASSERT_EQUAL(0,router_tool_set_connectionType(
    connectionType | bitsThatNeedToBeIgnored, &packed));
  TEST_ASSERT_EQUAL(0b11111110, packed);

  packed = 0xFF;
  TEST_ASSERT_EQUAL(0,router_tool_set_operationMode(
    operationMode | bitsThatNeedToBeIgnored, &packed));
  TEST_ASSERT_EQUAL(0b11110111, packed);

  packed = 0xFF;
  TEST_ASSERT_EQUAL(0,router_tool_set_wifiPowerAdjustment(
    wifiPowerAdjustment | bitsThatNeedToBeIgnored, &packed));
    TEST_ASSERT_EQUAL(0b11011111, packed);
}

/*-----------------------------------------------------------------*/
void test_router_tool_wifiEnabled(void) {
  uint8_t packed = 0xFF;
  TEST_ASSERT_EQUAL(0, router_tool_toggle_wifi_enabled(&packed));
  TEST_ASSERT_EQUAL(0b01111111, packed);
  TEST_ASSERT_EQUAL(false, router_tool_is_wifi_enabled(packed));

  TEST_ASSERT_EQUAL(0, router_tool_toggle_wifi_enabled(&packed));
  TEST_ASSERT_EQUAL(0xFF, packed);
  TEST_ASSERT_EQUAL(true, router_tool_is_wifi_enabled(packed));
}

/*-----------------------------------------------------------------*/
void test_router_tool_set_connectionType(void)
{
  uint8_t bitsThatNeedToBeIgnored =  0b10101000;
  uint8_t connectionType = 0b10;
  uint8_t packed = 0xFF;

  TEST_ASSERT_EQUAL(0,router_tool_set_connectionType(
    connectionType | bitsThatNeedToBeIgnored, &packed));
  TEST_ASSERT_EQUAL(0b11111110, packed);
}

/*-----------------------------------------------------------------*/
void test_router_tool_set_operationMode(void)
{
  uint8_t packed = 0b10101110;
  uint8_t bitsThatNeedToBeIgnored =  0b10101000;
  uint8_t operationMode = 0b10;

  TEST_ASSERT_EQUAL(0, router_tool_set_operationMode(
    operationMode | bitsThatNeedToBeIgnored, &packed));
  TEST_ASSERT_EQUAL(0b10101010, packed);
}

/*-----------------------------------------------------------------*/
void test_router_tool_set_wifiPowerAdjustment(void)
{
  uint8_t bitsThatNeedToBeIgnored =  0b10101000;
  uint8_t wifiPowerAdjustment = 0b101;
  uint8_t packed = 0xFF;

  TEST_ASSERT_EQUAL(0,router_tool_set_wifiPowerAdjustment(
    wifiPowerAdjustment | bitsThatNeedToBeIgnored, &packed));
    TEST_ASSERT_EQUAL(0b11011111, packed);
}

/*-----------------------------------------------------------------*/
void test_router_tool_pack_all_settings(void)
{
   uint8_t connectionType = 0b10;
   uint8_t operationMode = 0b11;
   uint8_t wifiPowerAdjustment = 0b101;
   bool wifiEnabled = true;
   uint8_t packed = 0b11011110;
   uint8_t actualPacked = 0;

  TEST_ASSERT_EQUAL(0,router_tool_pack_all_settings(
    connectionType, operationMode,
    wifiPowerAdjustment, wifiEnabled,
    &actualPacked));

  TEST_ASSERT_EQUAL(packed, actualPacked);
}

/*-----------------------------------------------------------------*/
void test_router_tool_unpack_all_settings(void)
{
   uint8_t connectionType = 0b10;
   uint8_t operationMode = 0b11;
   uint8_t wifiPowerAdjustment = 0b101;
   bool wifiEnabled = true;
   uint8_t packed = 0b11011110;

   uint8_t actualTurboBoost = 0;
   uint8_t actualThrottleResponse = 0;
   uint8_t actualSuspensionFirmness = 0;
   bool actualLaunchControlEnabled = false;

  TEST_ASSERT_EQUAL(0,router_tool_unpack_all_settings(packed,
    &actualTurboBoost, &actualThrottleResponse,
    &actualSuspensionFirmness, &actualLaunchControlEnabled));

  TEST_ASSERT_EQUAL(connectionType, actualTurboBoost);
  TEST_ASSERT_EQUAL(operationMode, actualThrottleResponse);
  TEST_ASSERT_EQUAL(wifiPowerAdjustment, actualSuspensionFirmness);
  TEST_ASSERT_EQUAL(wifiEnabled, actualLaunchControlEnabled);
}

/*-----------------------------------------------------------------*/
void test_router_tool_null_parameters_are_rejected(void) {
  uint8_t packed = 0;

  TEST_ASSERT_EQUAL(-1,router_tool_unpack_all_settings(packed,
    NULL, NULL, NULL, NULL));

  TEST_ASSERT_EQUAL(-1,router_tool_pack_all_settings(
    1, 2, 3, true, NULL));

  TEST_ASSERT_EQUAL(-1, router_tool_set_connectionType(2, NULL));
  TEST_ASSERT_EQUAL(-1, router_tool_set_operationMode(2, NULL));
  TEST_ASSERT_EQUAL(-1, router_tool_set_wifiPowerAdjustment(2, NULL));
  TEST_ASSERT_EQUAL(-1, router_tool_toggle_wifi_enabled(NULL));
}

/*-----------------------------------------------------------------*/
int main (int argc, char * argv[])
{
    UnityBegin();

    MY_RUN_TEST(test_router_tool_setters);
    MY_RUN_TEST(test_router_tool_wifiEnabled);
    MY_RUN_TEST(test_router_tool_set_connectionType);
    MY_RUN_TEST(test_router_tool_set_operationMode);
    MY_RUN_TEST(test_router_tool_set_wifiPowerAdjustment);
    MY_RUN_TEST(test_router_tool_pack_all_settings);
    MY_RUN_TEST(test_router_tool_unpack_all_settings);
    MY_RUN_TEST(test_router_tool_null_parameters_are_rejected);

    return UnityEnd();
}
