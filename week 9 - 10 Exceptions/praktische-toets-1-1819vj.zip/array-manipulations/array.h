#ifndef _ARRAY_H
#define _ARRAY_H

#include <stdlib.h>
#include <stdint.h>

/*!
  * Finding the minimum and maximum values of the array values.
  *
  * @param array: The address of the array
  * @param array_length: The length of the array
  * @param min_value: The address to which the minimum value of
	*                    the array will be written.
	* @param max_value: The address to which the maximum value of
	*                    the array will be written.
	*
  * @return: -1 when 'array', 'min_value' or 'max_value' are NULL,
  *           0 when succesull.
  */
int array_find_min_and_max_value(
			uint8_t* array,
	  	uint8_t array_length,
	    uint8_t* min_value,
	    uint8_t* max_value);

/*!
  * Finding the first index in the array where the elements equals the wanted_value.
  *
  * @param array: The address of the array
  * @param array_length: The length of the array
  * @param wanted_value: The value that must be found in the array.
	* @param index: The address to which the index value will be written.
	*
  * @return: -1 when 'array' or 'index' are NULL,
  *           0 when succesull.
  */
int array_find_first_occurence_of_value(
	 		uint8_t* array,
      uint8_t array_length,
      uint8_t wanted_value,
      uint8_t* index);

/*!
  * Removing all the elements in the array where the elements equals
	* the value_to_remove.
  *
  * @param array: The address of the array
  * @param array_length: The length of the array
  * @param value_to_remove: The value that must be removed from the array.
	* @param new_number_of_elements_in_array: The address to which the new number
	*                  of elements of the array must be written.
	*
  * @return: -1 when 'array' or 'new_array_length' are NULL,
  *           0 when succesull.
  */
int array_remove_all_occurences_of_value(
			uint8_t* array,
			uint8_t array_length,
			uint8_t value_to_remove,
			uint8_t* new_number_of_elements_in_array);

#endif
