#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "array.h"

int array_find_min_and_max_value(uint8_t* array,
							  	 uint8_t array_length,
							     uint8_t* min_value,
							     uint8_t* max_value)
{
	return 0;
}

int array_find_first_occurence_of_value(uint8_t* array,
					                    uint8_t array_length,
					                    uint8_t wanted_value,
					                    uint8_t* index)
{
	return 0;
}

int array_remove_all_occurences_of_value(uint8_t* array,
						uint8_t array_length,
						uint8_t value_to_remove,
						uint8_t* new_number_of_elements_in_array)
{
	return 0;
}
