#include "unity.h"
#include "array.h"

#define MY_RUN_TEST(func) RUN_TEST(func, 0)

void setUp(void)
{
}

void tearDown(void)
{
    //printf("This is run after EACH test.\n");
}

//TODO: add unit tests for the array.h methods

void test_your_test(void)
{
	uint8_t array[] = {2,8,4,10,4,9};

	TEST_ASSERT_EQUAL(4,array[2]);
}

int main (int argc, char * argv[])
{
    UnityBegin();

    MY_RUN_TEST(test_your_test);

    return UnityEnd();
}
