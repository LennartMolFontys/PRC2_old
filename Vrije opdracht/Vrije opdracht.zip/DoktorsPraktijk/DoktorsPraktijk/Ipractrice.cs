﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoktorsPraktijk
{
    interface Ipractrice
    {
        decimal Price { get; }
        string TreatmentName { get; }

    }
}
