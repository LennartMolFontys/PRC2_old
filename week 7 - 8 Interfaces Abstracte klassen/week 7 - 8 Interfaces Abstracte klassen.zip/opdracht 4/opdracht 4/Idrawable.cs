﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace opdracht_4
{
    public interface Idrawable
    {
        void DrawTo(Graphics drawingSurface);
    }
}
