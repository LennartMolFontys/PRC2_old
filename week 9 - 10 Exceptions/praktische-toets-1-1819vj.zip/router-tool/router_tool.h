#ifndef _ROUTER_TOOL_H
#define _ROUTER_TOOL_H

#include <stdint.h>
#include <stdbool.h>

/*!
	* Updates the connectionType bits within the packedRouterSettings byte.
  *
  * @param connectionType
	* @param packedRouterSetttings The address to which the packedRouterSettings
	*        will be written.
  * @return: 0 if input parameter(s) are valid,
  *         -1 if input parameter(s) are NULL.
  */
int router_tool_set_connectionType(
	uint8_t connectionType,
	uint8_t *packedRouterSetttings
);

/*!
	* Updates the operationMode bits within the packedRouterSettings byte.
  *
  * @param operationMode
  * @param packedRouterSetttings The address to which the packedRouterSettings
	*        will be written.
  *
  * @return: 0 if input parameter(s) are valid,
  *         -1 if input parameter(s) are NULL.
  */
int router_tool_set_operationMode(
	uint8_t operationMode,
	uint8_t *packedRouterSetttings
);

/*!
	* Updates the wifiPowerAdjustment bits within the packedRouterSettings byte.
  *
  * @param wifiPowerAdjustment
  * @param packedRouterSetttings The address to which the packedRouterSettings
	*        will be written.
  *
  * @return: 0 if input parameter(s) are valid,
  *         -1 if input parameter(s) are NULL.
  */
int router_tool_set_wifiPowerAdjustment(
	uint8_t wifiPowerAdjustment,
	uint8_t *packedRouterSetttings
);

/*!
	* Updates the launchControl bit within the packedRouterSettings byte.
	* 	A lauchControl bit with value 1 will become 0,
	* 	a lauchControl bit with value 0 will become 1.
	*
  * @param packedRouterSetttings
  *
  * @return: 0 if input parameter(s) are valid,
  *         -1 if input parameter(s) are NULL.
  */
int router_tool_toggle_wifi_enabled(
	uint8_t *packedRouterSetttings
);

/*!
	* Determines if lauchControl is enabled.
	* @param packedRouterSetttings
  * @return: true if lauchControl is enabled, otherwhise false.
  */
bool router_tool_is_wifi_enabled(
	uint8_t packedRouterSetttings
);

/*!
	* Pack the individual router settings into packedRouterSettings byte.
	* @param connectionType
	* @param operationMode
	* @param wifiPowerAdjustment
	* @param wifiEnabled
	* @param packedRouterSetttings The address to which the packedRouterSettings
	*        will be written.
  *
	* @return: 0 if input parameter(s) are valid,
  *         -1 if input parameter(s) are NULL.
  */
int router_tool_pack_all_settings(
 uint8_t connectionType,
 uint8_t operationMode,
 uint8_t wifiPowerAdjustment,
 bool wifiEnabled,
 uint8_t *packedRouterSetttings);

 /*!
 	* Unpack the individual router settings from the packedRouterSettings byte.
 	*
	* @param packedRouterSetttings
	* @param The address to which the connectionType value will be written.
 	* @param The address to which the operationMode value will be written.
 	* @param The address to which the wifiPowerAdjustment value will be written.
 	* @param The address to which the wifiEnabled value will be written.
 	*
 	* @return: 0 if input parameter(s) are valid,
   *         -1 if input parameter(s) are NULL.
   */
int router_tool_unpack_all_settings(
 uint8_t packedRouterSetttings,
 uint8_t *connectionType,
 uint8_t *operationMode,
 uint8_t *wifiPowerAdjustment,
 bool *wifiEnabled);

#endif
