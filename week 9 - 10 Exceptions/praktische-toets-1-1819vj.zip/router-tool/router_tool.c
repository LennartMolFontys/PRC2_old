#include <stddef.h> //Needed for NULL
#include "router_tool.h"

/*-----------------------------------------------------------------*/
int router_tool_set_connectionType(
 uint8_t connectionType,
 uint8_t *packedRouterSetttings)
{
	return 0;
}

/*-----------------------------------------------------------------*/
int router_tool_set_operationMode(
 uint8_t operationMode,
 uint8_t *packedRouterSetttings)
{
	return 0;
}

/*-----------------------------------------------------------------*/
int router_tool_set_wifiPowerAdjustment(
 uint8_t wifiPowerAdjustment,
 uint8_t *packedRouterSetttings)
{
	return 0;
}

/*-----------------------------------------------------------------*/
int router_tool_toggle_wifi_enabled(
 uint8_t *packedRouterSetttings)
{
	return 0;
}

/*-----------------------------------------------------------------*/
bool router_tool_is_wifi_enabled(
 uint8_t packedRouterSetttings)
{
	return false;
}

/*-----------------------------------------------------------------*/
int router_tool_pack_all_settings(
 uint8_t connectionType,
 uint8_t operationMode,
 uint8_t wifiPowerAdjustment,
 bool wifiEnabled,
 uint8_t *packedRouterSetttings)
{
	return 0;
}

/*-----------------------------------------------------------------*/
int router_tool_unpack_all_settings(
 uint8_t packedRouterSetttings,
 uint8_t *connectionType,
 uint8_t *operationMode,
 uint8_t *wifiPowerAdjustment,
 bool *wifiEnabled)
{
	return 0;
}
